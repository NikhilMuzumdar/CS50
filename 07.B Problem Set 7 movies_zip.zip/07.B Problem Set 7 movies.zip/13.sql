select distinct name from people join stars on people.id = stars.person_id join movies on stars.movie_id = movies.id

where
-- (1)
(
movies.id in
(select movies.id from people join stars on people.id = stars.person_id join movies on stars.movie_id = movies.id
where (name = 'Kevin Bacon' and birth = 1958))

and

-- (2)
people.id !=
(select people.id from people join stars on people.id = stars.person_id join movies on stars.movie_id = movies.id
where (name = 'Kevin Bacon' and birth = 1958))
)

order by name
;