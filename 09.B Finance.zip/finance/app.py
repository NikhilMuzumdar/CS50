import os

from cs50 import SQL
from flask import Flask, flash, redirect, render_template, request, session
from flask_session import Session
from tempfile import mkdtemp
from werkzeug.security import check_password_hash, generate_password_hash

from helpers import apology, login_required, lookup, usd
from datetime import datetime

# Configure application
app = Flask(__name__)

# Ensure templates are auto-reloaded
app.config["TEMPLATES_AUTO_RELOAD"] = True

# Custom filter
app.jinja_env.filters["usd"] = usd

# Configure session to use filesystem (instead of signed cookies)
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

# Configure CS50 Library to use SQLite database
db = SQL("sqlite:///finance.db")

# Make sure API key is set
if not os.environ.get("API_KEY"):
    raise RuntimeError("API_KEY not set")


@app.after_request
def after_request(response):
    """Ensure responses aren't cached"""
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Expires"] = 0
    response.headers["Pragma"] = "no-cache"
    return response


@app.route("/")
@login_required
def index():
    """Show portfolio of stocks"""

    # Fetch portfolio from the database, lookup the latest price etc
    portfolio = []
    stock_portfolio = db.execute(
        "SELECT stock_code, SUM(qty) FROM transactions WHERE user_id = ? GROUP BY stock_code", session["user_id"])

    for element in stock_portfolio:
        data = {
            'symbol': element['stock_code'],
            'name': lookup(symbol=element['stock_code'])['name'],
            'shares': element['SUM(qty)'],
            'price': usd(lookup(element['stock_code'])['price']),
            'value': usd(float(lookup(element['stock_code'])['price'] * element['SUM(qty)'])),
            'int_value': float(lookup(element['stock_code'])['price'] * element['SUM(qty)'])
        }
        portfolio.append(data)

    #  since database will have stock codes that total to 0 qty, eleminate such items
    for element in portfolio:
        if abs(element['shares']) == 0:
            portfolio.remove(element)

    flash_message = "Welcome to your portfolio summary:"
    portfolio_value = sum([element['int_value'] for element in portfolio])
    cash = db.execute("SELECT cash FROM users WHERE id == ?", session["user_id"])[0]['cash']
    total = portfolio_value + cash

    # Render the updated index
    return render_template("index.html", portfolio=portfolio, flash_message=flash_message, portfolio_value=usd(portfolio_value), cash=usd(cash), total=usd(total))


@app.route("/buy", methods=["GET", "POST"])
@login_required
def buy():
    """Buy shares of stock"""

    if request.method == "GET":
        return render_template("buy.html")

    else:
        stock_code = request.form.get("symbol").upper()
        qty = request.form.get("shares")

        # if stock code null
        if not stock_code:
            return apology("That is an invalid stock code!")

        # if qty null
        if not qty:
            return apology("Quantity not Entered!", 400)

        # if qty entered is a non digit
        if not qty.isdigit():
            return apology("Invalid quantity, must be a number!", 400)

        qty = float(qty)

        # if qty less than zero
        if qty <= 0:
            return apology("No of Shares cannot be Negative", 400)

        # if qty is a fraction
        if qty % 1 != 0:
            return apology("No of Shares cannot be fractional", 400)

        else:
            stock_data = lookup(symbol=stock_code)
            # if the symbol does not corrospond to any tax code
            if not stock_data:
                return apology("That stock code does not relate to any shares!")

            stock_price = stock_data["price"]
            available_balance = db.execute("SELECT cash FROM users WHERE id == ?", session["user_id"])[0]['cash']
            fund_required = stock_price * qty

            # check if funds are available to buy
            if available_balance < fund_required:
                return apology(f"Sorry, insufficient funds")
            else:
                execute_trade = True

        # if all avove conditions are ok
        if execute_trade:
            new_balance = available_balance - fund_required
            time_stamp = datetime.now()
            stock_name = stock_data["name"]
            # (1) Update Balance
            db.execute("UPDATE users SET cash=? WHERE id=?", new_balance, session['user_id'])

            # (2) Record Transaction : user_id, stock_code, qty, transaction_type, time_stamp, unit_price, total_price
            db.execute("INSERT INTO transactions (user_id, stock_code, qty, transaction_type, time_stamp, unit_price, total_value) VALUES (?,?,?,?,?,?,?)",
                       session["user_id"], stock_code, qty, "B", time_stamp, stock_price, fund_required)

            # update message to be flashed
            flash_message = f"Bought {qty} shares of {stock_name}!"

            # update portfolio to be displayed in the index page
            portfolio = []
            stock_portfolio = db.execute(
                "SELECT stock_code, SUM(qty) FROM transactions WHERE user_id = ? GROUP BY stock_code", session["user_id"])

            for element in stock_portfolio:
                data = {
                    'symbol': element['stock_code'],
                    'name': lookup(symbol=element['stock_code'])['name'],
                    'shares': element['SUM(qty)'],
                    'price': usd(lookup(element['stock_code'])['price']),
                    'value': usd(float(lookup(element['stock_code'])['price'] * element['SUM(qty)'])),
                    'int_value': float(lookup(element['stock_code'])['price'] * element['SUM(qty)'])
                }
                portfolio.append(data)

            # eleminate any shares that are of zero qty
            for element in portfolio:
                if abs(element['shares']) == 0:
                    portfolio.remove(element)

            portfolio_value = sum([element['int_value'] for element in portfolio])
            cash = db.execute("SELECT cash FROM users WHERE id == ?", session["user_id"])[0]['cash']
            total = portfolio_value + cash

            return render_template("index.html", portfolio=portfolio, flash_message=flash_message, portfolio_value=usd(portfolio_value), cash=usd(cash), total=usd(total))


@app.route("/history")
@login_required
def history():
    """Show history of share transactions"""
    # fetch history of all share transactions from database
    share_history = db.execute("SELECT * FROM transactions WHERE user_id = ?", session["user_id"])
    for entry in share_history:
        entry['unit_price'] = usd(entry['unit_price'])
        entry['total_value'] = usd(entry['total_value'])

    cash_history = db.execute("SELECT * FROM cash_transactions WHERE user_id = ?", session["user_id"])

    # apply usd formatting for all currencies
    for entry in cash_history:
        entry['cash'] = entry['cash']
        entry['total_balance'] = usd(entry['total_balance'])

    # update flash message
    flash_message = "Transaction History!"
    return render_template("history.html", share_data=share_history, cash_data=cash_history, flash_message=flash_message)


@app.route("/login", methods=["GET", "POST"])
def login():
    """Log user in"""

    # Forget any user_id
    session.clear()

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":

        # Ensure username was submitted
        if not request.form.get("username"):
            return apology("must provide username", 403)

        # Ensure password was submitted
        elif not request.form.get("password"):
            return apology("must provide password", 403)

        # Query database for username
        rows = db.execute("SELECT * FROM users WHERE username = ?", request.form.get("username"))

        # Ensure username exists and password is correct
        if len(rows) != 1 or not check_password_hash(rows[0]["hash"], request.form.get("password")):
            return apology("invalid username and/or password", 403)

        # Remember which user has logged in
        session["user_id"] = rows[0]["id"]

        # Redirect user to home page
        return redirect("/")

    # User reached route via GET (as by clicking a link or via redirect)
    else:
        return render_template("login.html")


@app.route("/logout")
def logout():
    """Log user out"""

    # Forget any user_id
    session.clear()

    # Redirect user to login form
    return redirect("/")


@app.route("/quote", methods=["GET", "POST"])
@login_required
def quote():
    """Get stock quote."""

    if request.method == "GET":
        return render_template("quote.html")

    else:
        symbol = request.form.get("symbol").upper()

        # check if the symbol was entered
        if not symbol:
            return apology("No symbol was entered")

        stock_data = lookup(symbol=symbol)

        # Check if symbol corrosponds to a valid stock data
        if not stock_data:
            return apology("That is an invalid stock code!")
        else:
            stock_name = stock_data["name"]
            stock_price = usd(stock_data["price"])

    return render_template("quoted.html", name=stock_name, price=stock_price)


@app.route("/register", methods=["GET", "POST"])
def register():
    """Register user"""

    if request.method == "GET":
        return render_template("register.html")

    # fetch details from the user
    else:
        username = request.form.get("username")
        password = request.form.get("password")
        confirmation = request.form.get("confirmation")

    # check if username was entered
    if not username:
        return apology("Please provide a username")

    #  check if password was entered
    elif not password:
        return apology("Please provide a password")

    # check if password = confirmation password
    elif password != confirmation:
        return apology("Passwords did not match!")

    # generate the password hash
    password_hash = generate_password_hash(password, method='pbkdf2:sha256', salt_length=8)

    # check if the username doesn't already exist
    if len(db.execute("SELECT username FROM users WHERE username == ?", username)) == 0:
        db.execute("INSERT INTO users (username, hash) VALUES (?, ?)", username, password_hash)
        return redirect("/")

    # inform user that the username is not available
    else:
        return apology("This username is already taken :(")


@app.route("/sell", methods=["GET", "POST"])
@login_required
def sell():
    """Sell shares of stock"""

    # Get the list of available stocks to sell
    available_stocks = []
    stock_portfolio = db.execute(
        "SELECT stock_code, SUM(qty) FROM transactions WHERE user_id = ? GROUP BY stock_code", session["user_id"])

    for element in stock_portfolio:
        data = {'symbol': element['stock_code'], 'shares': element['SUM(qty)']}
        available_stocks.append(data)

    for element in available_stocks:
        if abs(element['shares']) == 0:
            available_stocks.remove(element)

    if request.method == "GET":
        return render_template("sell.html", portfolio=available_stocks)

    else:
        symbol = request.form.get("symbol")
        sell_qty = request.form.get("shares")

        if not symbol:
            return apology("Sorry, please select a symbol")

        if not sell_qty:
            return apology("Sorry, enter valid qty to sell")

        sell_qty = float(sell_qty)

        if sell_qty <= 0:
            return apology("Quantity cannot be negative or zero")

        elif sell_qty % 1 != 0:
            return apology("Sell quantity cannot be fractional")

        else:
            available_stocks = db.execute(
                "SELECT stock_code, SUM(qty) FROM transactions WHERE user_id = ? GROUP BY stock_code", session["user_id"])
            stocks = {}
            for element in available_stocks:
                stocks[element['stock_code']] = element['SUM(qty)']

            if stocks[symbol] == 0:
                return apology(f"You donot own shares of {lookup(symbol)['name']}")

            if sell_qty > stocks[symbol]:
                return apology(f"You only own {stocks[symbol]} shares of {lookup(symbol)['name']}")

            else:
                stock_data = lookup(symbol)
                stock_price = stock_data["price"]
                available_balance = db.execute("SELECT cash FROM users WHERE id == ?", session["user_id"])[0]['cash']
                fund_generated = stock_price * sell_qty

                new_balance = available_balance + fund_generated
                time_stamp = datetime.now()
                stock_name = stock_data["name"]

                # (1) Update Cash Balance
                db.execute("UPDATE users SET cash=? WHERE id=?", new_balance, session['user_id'])

                # (2) Record Transaction : user_id, stock_code, qty, transaction_type, time_stamp, unit_price, total_price
                db.execute("INSERT INTO transactions (user_id, stock_code, qty, transaction_type, time_stamp, unit_price, total_value) VALUES (?,?,?,?,?,?,?)",
                           session["user_id"], symbol, -sell_qty, "S", time_stamp, stock_price, fund_generated)

                flash_message = f"Sold {sell_qty} shares of {stock_name}!"

                portfolio = []
                stock_portfolio = db.execute(
                    "SELECT stock_code, SUM(qty) FROM transactions WHERE user_id = ? GROUP BY stock_code", session["user_id"])

                for element in stock_portfolio:
                    data = {
                        'symbol': element['stock_code'],
                        'name': lookup(symbol=element['stock_code'])['name'],
                        'shares': element['SUM(qty)'],
                        'price': usd(lookup(element['stock_code'])['price']),
                        'value': usd(float(lookup(element['stock_code'])['price'] * element['SUM(qty)'])),
                        'int_value': float(lookup(element['stock_code'])['price'] * element['SUM(qty)'])
                    }
                    portfolio.append(data)

                for element in portfolio:
                    if abs(element['shares']) == 0:
                        portfolio.remove(element)

                portfolio_value = sum([element['int_value'] for element in portfolio])
                cash = db.execute("SELECT cash FROM users WHERE id == ?", session["user_id"])[0]['cash']
                total = portfolio_value + cash

                return render_template("index.html", portfolio=portfolio, flash_message=flash_message, portfolio_value=usd(portfolio_value), cash=usd(cash), total=usd(total))


@app.route("/passc", methods=["GET", "POST"])
@login_required
def change_password():
    """Change user_password"""

    if request.method == "GET":
        return render_template("passc.html")

    else:
        old_pass = request.form.get("old_pass")
        new_pass = request.form.get("new_pass")
        confirm_pass = request.form.get("confirm_pass")
        print(old_pass, new_pass, confirm_pass)

        if not old_pass:
            return apology("You did not provide your current password")

        if not new_pass:
            return apology("You did not the new password")

        if new_pass != confirm_pass:
            return apology("Confirmation password does not match")

        stored_pass = db.execute("SELECT hash FROM users where id = ?", session["user_id"])[0]['hash']

        if check_password_hash(stored_pass, old_pass):
            authorized = True
        else:
            return apology("Please entter correct current-password!")

        if authorized:
            db.execute("UPDATE users SET hash=? WHERE id=?", generate_password_hash(
                new_pass, method='pbkdf2:sha256', salt_length=8), session['user_id'])
            flash_message = "Password Updated!"
            return render_template("passc.html", flash_message=flash_message)


@app.route("/cash", methods=["GET", "POST"])
@login_required
def add_cash():
    """Change user_password"""

    if request.method == "GET":
        return render_template("cash.html")

    else:
        if request.form['action'] == 'add':
            factor = 1
            transaction_type = "Deopsit"
        else:
            factor = -1
            transaction_type = "Withdrawal"

        cash = request.form.get("cash")
        confirm = request.form.get("confirm")

        if not cash:
            return apology("You did not provide an input")

        if cash != confirm:
            return apology("Amounts do not match!")

        cash = float(cash)
        if cash <= 0:
            return apology("Amount should be greater than zero!")

        current_cash = db.execute("SELECT cash FROM users where id = ?", session["user_id"])[0]['cash']
        new_balance = current_cash + cash*factor

        if new_balance < 0:
            return apology("Sorry, insufficient funds!")

        # (1) Update the balance
        db.execute("UPDATE users SET cash=? WHERE id=?", new_balance, session['user_id'])

        # (2) Update the cash transactions table
        time_stamp = datetime.now()
        db.execute("INSERT INTO cash_transactions (user_id, cash, transaction_type, time_stamp, total_balance) VALUES (?,?,?,?,?)",
                   session["user_id"], cash*factor, transaction_type, time_stamp, new_balance)

        if factor == 1:
            flash_message = f"{usd(cash)} deposit successful, new balance is {usd(new_balance)}"
        else:
            flash_message = f"{usd(cash)} withdrawal successful, new balance is {usd(new_balance)}"

        return render_template("cash.html", flash_message=flash_message)