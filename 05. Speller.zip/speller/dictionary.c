// Implements a dictionary's functionality

#include <ctype.h>
#include <stdbool.h>

#include "dictionary.h"

// Include additional libraries
#include <string.h>
#include <strings.h>
#include <stdlib.h>
#include <stdio.h>



// Represents a node in a hash table
typedef struct node
{
    char word[LENGTH + 1];
    struct node *next;
}
node;

// TODO: Choose number of buckets in hash table
const unsigned int N = 26;

// Delcare variables
unsigned int word_count;
unsigned int hash_code;

// Hash table
node *table[N];

// Returns true if word is in dictionary, else false
bool check(const char *word)
{
    // TODO
    hash_code = hash(word);
    // Set pointer of cursor to the start of the linked list
    node *cursor = table[hash_code];

    // Traverse the linked list to check for a match till end of list is reached
    while (cursor != 0)
    {
        if (strcasecmp(word, cursor->word) == 0)
        {
            return true;
        }
        cursor = cursor->next;
    }
    return false;
}

// Hashes word to a number
unsigned int hash(const char *word)
{
    // TODO: Improve this hash function
    unsigned long total = 0;
    for (int i = 0, l = strlen(word); i < l; i ++)
    {
        total += tolower(word[i]);
    }

    return total % N;
}

// Loads dictionary into memory, returning true if successful, else false
bool load(const char *dictionary)
{
    // TODO
    FILE *file = fopen(dictionary, "r");

    // Return null if file open fails
    if (file == NULL)
    {
        printf("Unable to open the file %s", dictionary);
        return false;
    }

    // Declare the variable named word
    char word[LENGTH + 1];

    // Keep scaning the dictionary till the end of words (fscanf returns EOF)
    while (fscanf(file, "%s", word) != EOF)
    {
        // Allocate memory for the node to be generated
        node *n = malloc(sizeof(node));

        // If Malloc returns NULL, return false.
        if (n == NULL)
        {
            return false;
        }

        // Copy word from dictionary into the alloted node
        strcpy(n->word, word);
        hash_code = hash(word);
        n->next = table[hash_code];
        table[hash_code] = n;
        word_count ++;

    }
    fclose(file);
    return true;
}

// Returns number of words in dictionary if loaded, else 0 if not yet loaded
unsigned int size(void)
{
    // TODO
    if (word_count > 0)
    {
        return word_count;
    }

    return 0;
}

// Unloads dictionary from memory, returning true if successful, else false
bool unload(void)
{
    // TODO
    for (int i = 0; i < N; i++)
    {
        node *cursor = table[i];

        while (cursor != NULL)
            // if the cursor is not NULL, free temp
        {
            node *temp = cursor;
            cursor = cursor->next;
            free(temp);
        }

        if (cursor == NULL && i == N - 1)
        {
            return true;
        }
    }
    return false;
}
