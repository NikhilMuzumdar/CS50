# News updates using Telegram Bot & Selenium
#### Video Demo:  https://www.youtube.com/watch?v=FZqjwPOw8qs&t=8s
#### Description:

<br>
<h1> Background and Intent </h1>
<p>
    Often, we refer to more than one website for information that we like to read about. Typically, there never is a single place or site where such information is collated leading to users browsing multiple websites.
</p>
<p>
    I have tried to free some browsing time by developing a Telegram Bot that sends scheduled messages on topics / websites of interest (to me for now) that a user frequently visits. Using web scraping, a summary of such information is sent as a telegram message with a link to read further if the topic happens to be of interest.
</p>
<h1> Features</h1>
<ul>
    <li> Send messages from the chosen set of websites at a scheduled time. </li>
    <li> Respond to requests for information through predefined commands.</li>
    <li> Cache the source websites in a txt file so that repeated requests aren't made. </li>
    <li> Each message has timestamp of parsing to indicate aging.  </li>
</ul>

<h1> Softwares and Services</h1>
<ul>
    <li> Python with following libraries </li>
        <ul>
            <li>selenium</li>
            <li>PyTelegramBotApi</li>
            <li>pyshortners</li>
            <li>pytz</li>
            <li>threading</li>
        </ul>
    <li> Google Cloud Platform - for server hosting.
        <ul>
            <li>CS50 IDE could not be used due to installation requirement of various external libraries and dependencies that were reversed after each rebuild / update.
            </li>
        </ul>
    </li>
    <li>APIs:
        <ul>
            <li>Telegram bot API to integrate the bot with code</li>
            <li>PyTelegramBotApi</li>
        </ul>
    </li>
        <li>
            Linux based server / computer. <br>(Will need modifications in selenium to work with windows)
        </li>
</ul>

<h1>External parameters and prerequisites</h1>
<ul>
    <li> Requires a API from Telegram bot (TOKEN) which can be generated on telegram using botfather. For instructions refer <a href="https://core.telegram.org/bots/api#authorizing-your-bot">here</a>.  </li>
    <li> Install Google Chrome and compatible version of Chrome-driver on the linux machine.<br>
        Since the code is run in virtual machine, the browser will run in headless mode.</li>
    <li> For scheduled messages, user's CHAT_ID will be required for the bot will send message. Refer instructions <a href="https://www.alphr.com/find-chat-id-telegram/">here</a> to get the CHAT_ID</li>
    <li> Install the external libraries mentioned under "Software and services" [Selenuum, PyTelegramBotAPI, Pyshortners, pytz]  </li>
    <li> A log of all fetch / reply actions are maintained for reference along with time stamps. </li>
</ul>
<p><i>Please note that version changes in supported Libraries will need code modifications and updates.</p></i>

<h1>Implementation</h1>
<p>Code uses object oriented programming to define a object class named Scrapper. This stores inbuilt methods to scrap the target websites. Additional functions like shortening the url, converting time to local (IST) time and logging functions are also defined as methods within the Scrapper class scope. </p>
<p>The code is accordingly split into two parts
<ol>
    <li> Code for the Scrapper Class</li>
    <li> Code for the main function that defines the bot related functions</li>
</ol>


<h2>Scrapper class object</h2><hr>
<b>Imports for scrapper class</b><br>
<ul>
    <li>random - random.choice is used selecting a quote at random from scraped list<br></li>
    <li>selenium -  Web scrapping is implemented using selenium webdriver<br></li>
    <li>datetime - for use in logging fetch time and also all logs<br></li>
    <li>pytz - for converting time to local timezone<br></li>
    <li>pyshorteners - to compress long urls so that messages are not cluttered<br></li>
</ul>

<b>Websites that are scraped for data</b><br>
<ul>
    <li><a href="https://www.inshorts.com/en/read">Inshorts News</a><br></li>
    <li><a href="https://techcrunch.com/">Techcrunch</a><br></li>
    <li><a href="https://www.wionews.com/">Wion News</a><br></li>
    <li><a href="https://core.telegram.org/bots/api#authorizing-your-bot">Finshots</a><br></li>
    <li><a href="https://www.team-bhp.com/hot-threads">Team Bhp Threads</a><br></li>
    <li><a href="https://www.team-bhp.com/news">Team Bhp News</a><br></li>
    <li><a href="https://www.brainyquote.com/search_results?q=culture">Quotes</a><br></li>
</ul>

<b>Methods available in Scraper Function </b><br>
<ul>
    <li>Function to scrape respective website data & store the information in text file (<i>website</i>.write method)<br></li>
    <li>Function read from the text file and return a string for the bot to process (<i>website</i>.read method)<br></li>
    <li>A logger function that records the date and time of execution as a txt file<br></li>
    <li>URL shortner that uses pyshortner to compress the url length<br></li>
</ul>
<br>
<b>Brief on webscraping implementation </b><br>
<p>
    Having imported selenium, the program makes use of Webdriver and selenium.webdriver.common.by<br>
    Webdriver is initiated with below chromeoptions for implementation on linux (GCP virtual machine):
</p>
    <ul>
        <li>chrome_options = webdriver.ChromeOptions()</li>
        <li>chrome_options.add_argument('--no-sandbox')</li>
        <li>chrome_options.add_argument("--headless")</li>
        <li>chrome_options.add_argument("--disable-gpu")</li>
    </ul>
<i>For windows, this is slightly different. The chromedriver file path has to me mentioned as<br> driver = webdriver.Chrome(executable_path=path where the file is stored)</i><br><br>
<p>
The By method is used to extract web elements from the web pages. A typical example (in case of Inshorts) would be:<br>
<ul>
    <li>headlines = [element.text.split("\n")[0] for element in driver.find_elements(By.CLASS_NAME, 'news-card-title') if len(element.text.split("\n")[0]) > 30]</li>
    <li>contents = [element.text for element in driver.find_elements(By.CLASS_NAME, 'news-card-content')]</li>
</ul>
    In the code above, headline returns a list of strings which corresponds to the headlines available at the time of fetching the page. It uses the By.CLASS_NAME, 'news-card-title' method where it searches for class named news-card-title. This search returns a list of selenium objects that have attributes like .text and methods like get_attribute('required html tag') that help extract the required information. In this case the split("\n")[0] is used to split the sting and return only the headline.<br>
</p>
<p>
    Each of these headlines are then written into a text file along with time stamp and serial number. Serial number is important as we do not want to send too much text in one message. (There is also a limit of 4000 char in telegram). Having serial number allows the flexibility to choose top n messages.
</p>
<p>
    The point of writing the scraped data into a text file and not fetching the information each time a user requests is to reduce the number of website requests. With multiple users, this can quickly grow. We do not want to make too many server requests while it can be locally served. Also, Most information is updated by the day or by the hour, hence it does not serve any purpose to make the same request repeatedly. In the main function, the frequency of fetching website data is individually defined for each method / website.
</p>
<br>
<h2>Main Function</h2><hr>
<br>
<b>Imports for main function</b><br>
<ul>
    <li>from scraper import Scraper - The class we defined as above<br></li>
    <li>telebot-  This adds the bot object and it's functionalities. PyTelegramBotAPI library needs to be installed for this to work<br></li>
    <li>time module for scheduling messages, data parsing and also to add delay in functions.</li>
    <li>threading - the program runs two threads in parallel. Both threads make use of the same bot object initiated in the main.
        <br>Thread 1 - To listen to any commands a user might send to the bot
        <br>Thread 2 - To send scheduled message at time defined in the program.<br>
    </li>
    <li>os - to securely access TOKEN and CHAT_ID</li>
</ul>
<br>
<b>Initialization</b><br>
    <ul>
        <li>Initialize the bot using telebot method: <br>{bot = telebot.TeleBot(token=TOKEN)}</li>
        <li>Initialize Scrapper object {data = Scraper()}</li>
        <li>
            Run all write functions (methods) to save information in text files for use when requested through bot. This will take time as it involves multiple website scraping. Add sleep of 10 second in between to prevent errors as the webdriver quits and hops from one website to another.
        </li>
            <ul>
                <li>data.wion_write()</li>
                <li>data.team_bhp_news_write()</li>
                <li>data.finshots_write()</li>
                <li>data.this_day_in_past_write()</li>
                <li>data.team_bhp_threads_write()</li>
                <li>data.inshorts_write()</li>
                <li>data.techcrunch_write()</li>
            </ul>
<br>
</ul><b>Telegram Bot Infinite Polling</b><br>
<p>
    Infinite polling is a inbuilt function in PyTelegramBotAPI. This constantly listens for messages and upon command received through messaging, executes a function which is decorated under it. This is how our bot gets the functionality to listen to the persisted commands and respond.
</p>
<p>
    As an example, the command "/help" returns list of functions that the bot is capable of doing. Example code for the same is as under:<br><hr>
    @bot.message_handler(commands=['help'])<br>
    def send_welcome(message):<br>
    <ul>    bot.reply_to(message, "I provide following information"
                              ": \n\n/team_bhp_news\n\n/team_bhp_threads"
                              "\n\n/wion_news\n\n/finshots_updates\n\n/"
                              "quote_of_the_day\n\n/this_day_in_the_past"
                              "\n\n/inshorts\n\n/techcrunch_updates",
                     disable_web_page_preview=True,
                     )
    </ul>
<hr>
<p>
    A sample screen of how the bot response looks:<br>
    Note that the bot responds with ready to click hyperlinked commands that when clicked upon provides the information.
</p>
<img src="/workspaces/65347048/project/media/01. help command.jpg" width=50%>
<p>
    These bot response commands work similar to the help command demonstrated above. The infinite polling function decorates a function under it (which we defined as a method in scrapper) and returns a string that is sent by the bot.
</p>
</img>
</p>
</ul><b>Telegram Bot Scheduled Messaging</b><br>
<p>
    At the stated time of the day, bot sends the information to user. The time is based on nature of the websites and the frequency of information update.
    <br><i>
    As a feature update, this can also be modified such that the user can select the websites and time. At the moment however, this functionality is unavailable
    </i>
    <br>Currently, for each functions, the hours are defined as under:<br><ul>
    wion_hrs = [7, 10, 14, 16, 18, 20, 23]<br>
    tbhp_ht_hrs = [9, 13]<br>
    tbhp_news_hrs = [12, 19]<br>
    finshots_hrs = [8]<br>
    this_day_in_past_hrs = [5]<br>
    culture_quotes_hrs = [7]<br>
    inshorts_hrs = list(range(6, 24))<br>
    tech_chrunch_hrs = [8, 20]<br></ul>
</p>
<br>
</ul><b>Keeping the data updated</b><br>
<p>
    Data is updated by the hr, when the minute strikes 45. As all the scheduled messages are sent at the hr (whole number), this ensures that the data is updated 15 minutes prior.
</p>
<p>
    We also have to ensure some checks in this process since this runs in a while loop constantly:<br>
    <ul>
        There is a 2 min window between minute 45 and 47 where the information is updated. This is achieved through the initialize function that runs all the parsing functions in scraper. If this process completes within 2 minutes, we do not want to repeat this process. Hence a delay of 120 sec is added do ensure this does not happen.<br>
    </ul>
    <ul>
        The main while loop that checks for time runs constantly. We can slow this down to one check per minute as it need not be instant. This improves processor loading significantly while still accomplishing the desired result.
    </ul>
</p>
<br>
</ul><b>Use of multi-threading</b><br>
<p>
    The program needs to run two parallel functions:
    <ul>
        One that listens to the commands from users
    </ul>
    <ul>
        One that checks time and sends scheduled messages
    </ul>
    This is achieved with the use of threading.
</p>

</p>
</ul><b>Status updates and logging</b><br>
<p>
    To provide feedback on the health of the program, logs are maintained. When the main program runs for example, a message is printed "Bot is listening". This provides the server user, a confirmation on the process beginning. Likewise, if the program is ended, when both the function threads are terminated, the message "Bot is sleeping" is printed to provide confirmation on termination.
</p>
<p>
    All functions inherently log time stamp and the function name and maintain a "logger.txt" file that gives historic record of the time of scraping.
</p>

<h1>Credits</h1>
    <ul>
        <li> <a href="https://www.selenium.dev/documentation/webdriver/">Selenium Webdriver</a> </li>
        <li> <a href="https://pypi.org/project/pyTelegramBotAPI/">pyTelegramBotAPI 4.6.1</a> </li>
        <li> <a href="https://pypi.org/project/pyshorteners/">pyshorteners 1.0.1</a> </li>
        <li> <a href="https://pypi.org/project/pytz/">pytz 2022.1</a> </li>
    </ul>
<br><br><hr>
<h1>Thank you CS50!</h1>